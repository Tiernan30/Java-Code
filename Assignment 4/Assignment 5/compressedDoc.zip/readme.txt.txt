Compile and run all files, (Greenhouse.java has the main method)

Save state/load state:
Only saves the state on button press, and loads the state on press.

Note:
The load will not update the JSliders as they are updated when start is pushed. 
Load will update all the text boxes and the JComboBox
